package discovery;

import java.util.ArrayList;

import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.FilterCriteriaDTO;
import org.osgi.service.onem2m.dto.FilterCriteriaDTO.FilterUsage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh21 {
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh21.class);

	public static void discoveryCinRequest(ServiceLayer serviceLayerService, String uri, FilterCriteriaDTO fc) {
		LOGGER.info("----START CONTENTINSTANCE DISCOVERY!!!----");

		// Set a value for FilterUsage and SemanticsFilter.
		fc.semanticsFilter = new ArrayList<String>();
		fc.semanticsFilter.add("");
		fc.semanticsFilter.add("");
		fc.filterUsage = FilterUsage.DiscoveryCriteria;

		// Request for discovering an AE.
		serviceLayerService.discovery(uri, fc);
		LOGGER.info("----END CONTENTINSTANCE DISCOVERY!!!----");
	}
}
