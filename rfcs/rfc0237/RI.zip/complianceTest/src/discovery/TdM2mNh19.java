package discovery;

import java.util.ArrayList;

import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.AttributeDTO;
import org.osgi.service.onem2m.dto.FilterCriteriaDTO;
import org.osgi.service.onem2m.dto.FilterCriteriaDTO.FilterUsage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh19 {
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh19.class);

	public static void discoveryCinRequest(ServiceLayer serviceLayerService, String uri, FilterCriteriaDTO fc) {
		LOGGER.info("----START CONTENTINSTANCE DISCOVERY!!!----");
		// Set a value for FilterUsage and Attribute.
		AttributeDTO at1 = new AttributeDTO();
		at1.name = "";
		at1.value = "";
		fc.attribute = new ArrayList<AttributeDTO>();
		fc.attribute.add(at1);
		fc.filterUsage = FilterUsage.DiscoveryCriteria;

		// Request for discovering an AE.
		serviceLayerService.discovery(uri, fc);
		LOGGER.info("----END CONTENTINSTANCE DISCOVERY!!!----");
	}
}
