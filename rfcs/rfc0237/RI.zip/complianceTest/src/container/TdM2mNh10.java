package container;

import java.util.HashMap;
import java.util.Map;

import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.ResourceDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh10 {
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh10.class);

	public static void createConRequest(ServiceLayer serviceLayerService, String uri) {
		try {
			// Request for Creating an AE; the Preparing for the following
			// processing.
			LOGGER.info("----START THE CONTAINER CREATE PREPARATION!!!----");
			ResourceDTO ae = new ResourceDTO();
			ae.resourceType = 2;
			ae.resourceName = "SampleAE";
			Map<String, Object> aeAttr = new HashMap<String, Object>();
			aeAttr.put("App-ID", "SampleAE");
			aeAttr.put("requestReachability", "true");
			aeAttr.put("pointOfAccess", "http://127.0.0.1:38080/complianceTest");
			ae.attribute = aeAttr;
			serviceLayerService.create("http://127.0.0.1:8080/in-name", ae);
			LOGGER.info("----END THE CONTAINER CREATE PREPARATION!!!----");

			Thread.sleep(2000);

			LOGGER.info("----START CONTAINER CREATE!!!----");

			// Specify the resource type and name.
			ResourceDTO con = new ResourceDTO();
			con.resourceType = 3;
			con.resourceName = "SampleCon";

			// Request for creating a container.
			serviceLayerService.create(uri, con);

			LOGGER.info("----END CONTAINER CREATE!!!----");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
