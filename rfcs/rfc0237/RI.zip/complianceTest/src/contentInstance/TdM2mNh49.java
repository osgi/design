package contentInstance;

import java.util.HashMap;
import java.util.Map;

import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.ResourceDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh49 {
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh49.class);

	public static void deleteCinRequest(ServiceLayer serviceLayerService, String uri) {
		try {

			// Request for creating a ContentInstance.
			LOGGER.info("----START CONTENTINSTANCE CREATE!!!----");
			ResourceDTO cin = new ResourceDTO();
			cin.resourceType = 4;
			cin.resourceName = "SampleCin2";
			Map<String, Object> attr1 = new HashMap<String, Object>();
			attr1.put("content", "1");
			cin.attribute = attr1;
			serviceLayerService.create(uri, cin);
			LOGGER.info("----END CONTENTINSTANCE CREATE!!!----");

			Thread.sleep(2000);

			// Request for retrieving the latest ContentInstance in a Container.
			LOGGER.info("----START CONTAINER RETRIEVE!!!----");
			serviceLayerService.retrieve(uri + "/la", new ResourceDTO());
			LOGGER.info("----END CONTAINER RETRIEVE!!!----");

			Thread.sleep(2000);

			// Request for deleting a ContentInstance.
			LOGGER.info("----START CONTENTINSTANCE DELETE!!!----");
			serviceLayerService.delete(uri + "/SampleCin2");
			LOGGER.info("----END CONTENTINSTANCE DELETE!!!----");

			Thread.sleep(2000);

			// Request for retrieving the latest ContentInstance in a Container
			LOGGER.info("----START CONTAINER RETRIEVE!!!----");
			serviceLayerService.retrieve(uri + "/la", new ResourceDTO());
			LOGGER.info("----END CONTAINER RETRIEVE!!!----");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
