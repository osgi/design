package contentInstance;

import java.util.HashMap;
import java.util.Map;

import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.ResourceDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh14 {
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh14.class);

	public static void createCinRequest(ServiceLayer serviceLayerService, String uri) {
		try {
			// Retrieve Container data before creating a ContentInstance
			LOGGER.info("----START CONTAINER RETRIEVE (BEFORE)!!!----");
			serviceLayerService.retrieve(uri, new ResourceDTO());
			LOGGER.info("----END CONTAINER RETRIEVE (BEFORE)!!!----");

			Thread.sleep(2000);


			LOGGER.info("----START CONTENTINSTANCE CREATE!!!----");

			// Specify the resource type and name.
			ResourceDTO cin = new ResourceDTO();
			cin.resourceType = 4;
			cin.resourceName = "SampleCin";


			// Specify attribute name and value.
			Map<String, Object> attr = new HashMap<String, Object>();
			attr.put("content", "1");
			cin.attribute = attr;

			// Request for creating an AE.
			serviceLayerService.create(uri, cin);

			LOGGER.info("----END CONTENTINSTANCE CREATE!!!----");
			Thread.sleep(2000);

			// Retrieve Container data after creating a ContentInstance
			LOGGER.info("----START CONTAINER RETRIEVE (AFTER)!!!----");
			serviceLayerService.retrieve(uri, new ResourceDTO());
			LOGGER.info("----END CONTAINER RETRIEVE (AFTER)!!!----");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
