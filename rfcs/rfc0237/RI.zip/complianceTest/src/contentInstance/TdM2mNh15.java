package contentInstance;

import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.ResourceDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh15{
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh15.class);

	public static void retrieveCinRequest(ServiceLayer serviceLayerService, String uri) {
		// Request for Retrieving AE data.
		LOGGER.info("----START CONTENTINSTANCE RETRIEVE!!!----");
		serviceLayerService.retrieve(uri, new ResourceDTO());
		LOGGER.info("----END CONTENTINSTANCE RETRIEVE!!!----");
	}
}
