package compliancetest;

import org.osgi.service.onem2m.NotificationListener;
import org.osgi.service.onem2m.dto.RequestPrimitiveDTO;
import org.osgi.service.onem2m.dto.ResourceDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NotificationListenerImpl implements NotificationListener {
	private static final Logger LOGGER = LoggerFactory.getLogger(NotificationListenerImpl.class);
	private static String bundleSymbolicName = null;

	public void setBundleSymbolicName(String bundleSymbolicName){
		this.bundleSymbolicName = bundleSymbolicName;
	}

	public String getBundleSymbolicName(){
		return this.bundleSymbolicName;
	}

	/*
	 * (Non Javadoc)
	 * @see org.osgi.service.onem2m.NotificationListener#notified(org.osgi.service.onem2m.dto.RequestPrimitiveDTO)
	 */
	@Override
	public void notified(RequestPrimitiveDTO request) {
		LOGGER.info("receive Notify!!!");

		// receive notification.
		ResourceDTO dto = request.content.resource;

		LOGGER.debug("[Json -> Java]");
		LOGGER.debug("resourceType" + " : " + dto.resourceType);
		LOGGER.debug("resourceID" + " : " + dto.resourceID);
		LOGGER.debug("parentID" + " : " + dto.parentID);
		LOGGER.debug("creationTime" + " : " + dto.creationTime);
		LOGGER.debug("lastModifiedTime" + " : " + dto.lastModifiedTime);
		LOGGER.debug("resourceName" + " : " +  dto.resourceName);
		LOGGER.debug("labels" + " : " +  dto.labels);
		LOGGER.debug("attribute" + " : " + dto.attribute);
	}

}
