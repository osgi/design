package compliancetest;

import java.util.Hashtable;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.onem2m.NotificationListener;
import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.FilterCriteriaDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import applicationEntity.TdM2mNh06;
import applicationEntity.TdM2mNh07;
import applicationEntity.TdM2mNh08;
import applicationEntity.TdM2mNh09;
import container.TdM2mNh10;
import contentInstance.TdM2mNh14;
import contentInstance.TdM2mNh15;
import contentInstance.TdM2mNh49;
import cseBaseManagement.TdM2mNh01;
import discovery.TdM2mNh18;
import discovery.TdM2mNh19;
import discovery.TdM2mNh21;
import notification.TdM2mNh48;
import subscription.TdM2mNh22;

public class Activator implements BundleActivator{
	private static final Logger LOGGER = LoggerFactory.getLogger(Activator.class);

	private static BundleContext context;

	private static String bundleSymbolicName = null;

	static BundleContext getContext() {
		return context;
	}

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext bundleContext) throws Exception {
		LOGGER.info("start sample bundle");

		Activator.context = bundleContext;
		bundleSymbolicName = context.getBundle().getSymbolicName();

		// Register the service of the following processing after receiving the notification.
        Hashtable<String, String> tbl = new Hashtable<String, String>();
        tbl.put("symbolicName", bundleSymbolicName);
		NotificationListener notificationListener = new NotificationListenerImpl();
        context.registerService(NotificationListener.class, notificationListener, tbl);

		// Get the PB Service factory.
		ServiceReference<?> serviceLayerFactory = context.getServiceReference(ServiceLayer.class.getName());
		ServiceLayer serviceLayerService = (ServiceLayer) context.getService(serviceLayerFactory);

		if(serviceLayerService == null){
			LOGGER.warn("Create Service Failed");
			return;
		}

		// 1.RETRIEVE in a CSE-BASE
		TdM2mNh01.retrieveCSERequest(serviceLayerService, "http://127.0.0.1:8080/in-name");

		Thread.sleep(2000);

		// 2.CREATE an AE
		TdM2mNh06.createAERequest(serviceLayerService, "http://127.0.0.1:8080/in-name");

		Thread.sleep(2000);

		// 3.RETRIEVE AE data
		TdM2mNh07.retrieveAERequest(serviceLayerService, "http://127.0.0.1:8080/in-name/SampleAE");

		Thread.sleep(2000);

		// 4.UPDATE AE data
		TdM2mNh08.updateAERequest(serviceLayerService, "http://127.0.0.1:8080/in-name/SampleAE");

		Thread.sleep(2000);

		// 5.DELETE an AE
		TdM2mNh09.deleteAERequest(serviceLayerService, "http://127.0.0.1:8080/in-name/SampleAE");

		Thread.sleep(2000);

		// 6.CREATE a Container
		TdM2mNh10.createConRequest(serviceLayerService, "http://127.0.0.1:8080/in-name/SampleAE");

		Thread.sleep(2000);

		// 7.CREATE a ContentInstance
		TdM2mNh14.createCinRequest(serviceLayerService, "http://127.0.0.1:8080/in-name/SampleAE/SampleCon");

		Thread.sleep(2000);

		// 8.RETRIEVE ContentInstance data
		TdM2mNh15.retrieveCinRequest(serviceLayerService, "http://127.0.0.1:8080/in-name/SampleAE/SampleCon/SampleCin");

		Thread.sleep(2000);

		// 9.DELETE a ContentInstance
		TdM2mNh49.deleteCinRequest(serviceLayerService, "http://127.0.0.1:8080/in-name/SampleAE/SampleCon");

		Thread.sleep(2000);

		// 10.DISCOVERY an AE
		TdM2mNh18.discoveryCinRequest(serviceLayerService, "http://127.0.0.1:8080/in-name", new FilterCriteriaDTO());

		Thread.sleep(2000);

		// 11.DISCOVERY an AE; using Label of FilterCriteria
		TdM2mNh19.discoveryCinRequest(serviceLayerService, "http://127.0.0.1:8080/in-name", new FilterCriteriaDTO());

		Thread.sleep(2000);

		// 12.DISCOVERY an AE; using Multiple of FilterCriteria
		TdM2mNh21.discoveryCinRequest(serviceLayerService, "http://127.0.0.1:8080/in-name", new FilterCriteriaDTO());

		Thread.sleep(2000);

		// 13.CREATE a Subscription
		TdM2mNh22.createSubRequest(serviceLayerService, "http://127.0.0.1:8080/in-name/SampleAE");

		Thread.sleep(2000);

		// 14.The proccessing for checking the notification.
		TdM2mNh48.notifyRequest(serviceLayerService, "http://127.0.0.1:8080/in-name/SampleAE");
	}

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext bundleContext) throws Exception {
		Activator.context = null;
	}

}
