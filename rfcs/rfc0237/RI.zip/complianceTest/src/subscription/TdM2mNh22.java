package subscription;

import java.util.HashMap;
import java.util.Map;

import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.ResourceDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh22{
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh22.class);

	public static void createSubRequest(ServiceLayer serviceLayerService, String uri) {
		LOGGER.info("----START SUBSCRIPTION CREATE!!!----");

		// Specify the resource type and name.
		ResourceDTO ae = new ResourceDTO();
		ae.resourceType = 23;
		ae.resourceName = "SampleSub";
		Map<String, Object> aeAttr = new HashMap<String, Object>();
		aeAttr.put("notificationURI", "http://127.0.0.1:38080/complianceTest");
		ae.attribute = aeAttr;

		// Request for creating a Subscription..
		serviceLayerService.create("http://127.0.0.1:8080/in-name", ae);

		LOGGER.info("----END SUBSCRIPTION CREATE!!!----");
	}
}
