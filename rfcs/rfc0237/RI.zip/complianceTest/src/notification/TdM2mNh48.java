package notification;

import java.util.HashMap;
import java.util.Map;

import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.NotificationDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh48{
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh48.class);

	public static void notifyRequest(ServiceLayer serviceLayerService, String uri) {
		LOGGER.info("----START CHECKING NOTIFICATION!!!----");

		// Specify the reference.
		NotificationDTO notification = new NotificationDTO();
		Map<String, Object> nev = new HashMap<String, Object>();
		nev.put("representation", 1);
		notification.notificationEvent = nev;
		notification.subscriptionDeletion = false;
		notification.subscriptionReference = "http://127.0.0.1:8080/in-name/SampleAE";

		// Request for notifying.
		serviceLayerService.notify("http://127.0.0.1:8080/in-name/SampleAE", notification);

		LOGGER.info("----START CHECKING NOTIFICATION!!!----");

		// After proccess is over, check the logs.
	}
}
