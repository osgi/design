package applicationEntity;

import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.ResourceDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh07{
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh07.class);

	public static void retrieveAERequest(ServiceLayer serviceLayerService, String uri)  {
		LOGGER.info("----START AE RETRIEVE!!!----");

		//Request for retrieving AE data.
		serviceLayerService.retrieve(uri, new ResourceDTO());

		LOGGER.info("----END AE RETRIEVE!!!----");
	}
}