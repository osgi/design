package applicationEntity;

import java.util.HashMap;
import java.util.Map;

import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.ResourceDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh06{
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh06.class);

	public static void createAERequest(ServiceLayer serviceLayerService, String uri) {
		LOGGER.info("----START AE CREATE!!!----");

		// Specify the resource type and name.
		ResourceDTO ae = new ResourceDTO();
		ae.resourceType = 2;
		ae.resourceName = "SampleAE";

		// Specify attribute name and value.
		Map<String, Object> attr = new HashMap<String, Object>();
		attr.put("App-ID", "SampleAE");
		attr.put("requestReachability", "true");
		attr.put("pointOfAccess", "http://127.0.0.1:38080/complianceTest");
		ae.attribute = attr;

		// Request for creating an AE.
		serviceLayerService.create(uri, ae);

		LOGGER.info("----END AE CREATE!!!----");
	}
}
