package applicationEntity;

import org.osgi.service.onem2m.ServiceLayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh09{
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh09.class);

	public static void deleteAERequest(ServiceLayer serviceLayerService, String uri)  {
		LOGGER.info("----START AE DELETE!!!----");

		// Request for deleting an AE.
		serviceLayerService.delete(uri);

		LOGGER.info("----END AE DELETE!!!----");
	}
}