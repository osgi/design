package applicationEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.dto.ResourceDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TdM2mNh08{
	private static final Logger LOGGER = LoggerFactory.getLogger(TdM2mNh08.class);

	public static void updateAERequest(ServiceLayer serviceLayerService, String uri)  {
		LOGGER.info("----START AE UPDATE!!!----");

		// Specify the resource type.
		ResourceDTO ae = new ResourceDTO();
		ae.resourceType = 2;

		// Specify attribute name and value to update.

		Map<String, Object> attrCnt = new HashMap<String, Object>();
		List<String> lbl = new ArrayList<String>();
		lbl.add("SampleList");
		attrCnt.put("labels", lbl);
		ae.attribute = attrCnt;

		//Request for updating AE data.
		serviceLayerService.update(uri, ae);

		LOGGER.info("----END AE UPDATE!!!----");
	}
}