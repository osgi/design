/**
 * This package includes requestsample for AE Sample.
 */
package org.osgi.service.onem2m.ae.sample;
