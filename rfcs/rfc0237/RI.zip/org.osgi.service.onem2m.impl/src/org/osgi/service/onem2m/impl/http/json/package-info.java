/**
 * This package includes http json Implementation for oneM2M service layer API.
 */
package org.osgi.service.onem2m.impl.http.json;
