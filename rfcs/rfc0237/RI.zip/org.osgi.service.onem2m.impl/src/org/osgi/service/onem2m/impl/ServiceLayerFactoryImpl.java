package org.osgi.service.onem2m.impl;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.Map;

import javax.servlet.ServletException;

import org.osgi.framework.Bundle;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceFactory;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;
import org.osgi.service.http.HttpService;
import org.osgi.service.http.NamespaceException;
import org.osgi.service.onem2m.NotificationListener;
import org.osgi.service.onem2m.ServiceLayer;
import org.osgi.service.onem2m.impl.http.json.NotificationServlet;
import org.osgi.service.onem2m.impl.http.json.ServiceLayerImpl;
import org.osgi.service.onem2m.impl.http.json.ServiceLayerUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServiceLayerFactoryImpl implements ServiceFactory<ServiceLayer> {
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceLayerFactoryImpl.class);

	@Override
	public ServiceLayer getService(Bundle bundle, ServiceRegistration<ServiceLayer> registration) {

		LOGGER.info("Start factory");

		String bundleSymbolicName = bundle.getSymbolicName();

		// get Properties
		Map<String, String> property = ServiceLayerUtil.getProperty(bundleSymbolicName, bundle.getBundleContext());
		ServiceLayer sl = null;

		if (property == null) {
			LOGGER.warn(bundleSymbolicName + " is no property.");
			return null;
		}

		if (!ServiceLayerUtil.PROTOCOL_HTTP.equals(property.get(ServiceLayerUtil.PROTOCOL).toLowerCase())
				&& !ServiceLayerUtil.SERIALIZE_JSON.equals(property.get(ServiceLayerUtil.SERIALIZE).toLowerCase())) {
			LOGGER.warn(property.get(ServiceLayerUtil.PROTOCOL) + " & " + property.get(ServiceLayerUtil.SERIALIZE)
					+ " is Unimplemented.");
			return null;
		}

		// Create ServiceLayer Service
		sl = new ServiceLayerImpl(property.get(ServiceLayerUtil.ORIGIN));

		// get NotificationListener Service
		Collection<ServiceReference<NotificationListener>> notificationListenerServices = null;
		try {
			notificationListenerServices = bundle.getBundleContext().getServiceReferences(
					NotificationListener.class, "(" + ServiceLayerUtil.PROPERTY_KEY + "=" + bundleSymbolicName + ")");
		} catch (InvalidSyntaxException e) {
			LOGGER.warn("NotificationListener Acquisition failure.", e);
			return null;
		}
		ServiceReference<NotificationListener> notificationListenerService = notificationListenerServices.iterator()
				.next();
		NotificationListener listener = bundle.getBundleContext().getService(notificationListenerService);

		// get alias
		URI uri = null;
		try {
			uri = new URI(property.get(ServiceLayerUtil.POA));
		} catch (URISyntaxException e) {
			LOGGER.warn("Property PoA is Not URI.", e);
			return null;
		}
		String[] splitUri = (property.get(ServiceLayerUtil.POA)).split(uri.getRawAuthority());

		// register Servlet
		ServiceReference<?> sRef = bundle.getBundleContext().getServiceReference(HttpService.class.getName());
		if (sRef != null) {
			HttpService service = (HttpService) bundle.getBundleContext().getService(sRef);
			NotificationServlet servlet = new NotificationServlet(listener);
			try {
				service.registerServlet(splitUri[1], servlet, null, null);
			} catch (ServletException | NamespaceException e) {
				LOGGER.warn("ServletRegist failed", e);
			}
		}

		LOGGER.info("End factory");

		return sl;
	}

	@Override
	public void ungetService(Bundle bundle, ServiceRegistration<ServiceLayer> registration, ServiceLayer service) {
		// NOP

	}

}
