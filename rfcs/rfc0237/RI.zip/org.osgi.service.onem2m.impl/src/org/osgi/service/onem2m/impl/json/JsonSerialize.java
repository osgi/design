package org.osgi.service.onem2m.impl.json;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.osgi.service.onem2m.dto.NotificationDTO;
import org.osgi.service.onem2m.dto.ResourceDTO;
import org.osgi.service.onem2m.impl.http.json.ServiceLayerImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonSerialize {

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceLayerImpl.class);

	public static ResourceDTO jsonToResource(String json) throws Exception {

		LOGGER.info("Start jsonToResource");

		ResourceDTO returnRes = new ResourceDTO();
		ObjectMapper mapper = new ObjectMapper();

		try {
			List<UnknownObject> jsonlist = new ArrayList<>();

			JsonNode node = mapper.readTree(json);

			String resourceTypeName = null;
			Iterator<String> fieldNames = node.fieldNames();
			while (fieldNames.hasNext()) {
				resourceTypeName = fieldNames.next();
			}
			node = node.get(resourceTypeName);

			if (node.isArray()) {
				jsonlist.addAll(Arrays.asList(mapper.readValue(node.traverse(), UnknownObject[].class)));
			} else {
				jsonlist.add(mapper.readValue(node.traverse(), UnknownObject.class));
			}

			Map<String, Object> attr = new HashMap<String, Object>();
			Field[] varArray = returnRes.getClass().getFields();

			for(UnknownObject data: jsonlist){
				Map<String, Object> prop = data.getAnyProperties();
				Set<String> keys = data.getAnyProperties().keySet();
				Object value = null;

				for(String key: keys){

					if (prop.get(key) instanceof ArrayList) {
						ArrayList<Object> list = new ArrayList<Object>();

						for(int i = 0; i < ((ArrayList<?>)prop.get(key)).size(); i++){
							list.add((((ArrayList<?>)prop.get(key)).get(i)));
						}
						value = list;
					}else{
						value = prop.get(key);
					}

					for(int i = 0; i < varArray.length; i++){
						Field var = varArray[i];
						if(var.getName().equals(LongShortConverter.s2l(key))){
							var.set(returnRes, value);
							break;
						}

						if(i == varArray.length - 1){
							if(value instanceof Map){
								Map<String, Object> attrMap = new HashMap<String, Object>();
								Set<String> attrKeys = ((Map<String, Object>)value).keySet();
								for(String attrKey: attrKeys){
									attrMap.put(LongShortConverter.s2l(attrKey), ((Map) value).get(attrKey));
								}
								attr.put(LongShortConverter.s2l(key), attrMap);
							} else {
								attr.put(LongShortConverter.s2l(key), value);
							}
						}
					}
				}
			}

			for(int i = 0; i < varArray.length; i++){
				if(varArray[i].getName().equals("attribute")){
					varArray[i].set(returnRes, attr);
				}
			}

		} catch (Exception e) {
			LOGGER.warn("error!");
			e.printStackTrace();
		}

		LOGGER.info("End jsonToResource");

		return returnRes;
	}


	public static String resourceToJson(ResourceDTO dto) throws Exception  {

		String jsonRes = "";

		String resourceTypeName = null;
		switch(dto.resourceType){
			case 2:
				resourceTypeName = "m2m:ae";
				break;
			case 3:
				resourceTypeName = "m2m:cnt";
				break;
			case 4:
				resourceTypeName = "m2m:cin";
				break;
			case 23:
				resourceTypeName = "m2m:sub";
				break;
		}

		Field[] varArray = dto.getClass().getFields();
		for(int i = 0; i < varArray.length; i++){
			Field var = varArray[i];
			if(var.getName().equals("resourceType")
					|| var.getName().equals("resourceID")
					|| var.getName().equals("parentID")
					|| var.getName().equals("creationTime")
					|| var.getName().equals("lastModifiedTime")
					){
				continue;
			}

			if(!var.getName().equals("attribute") && !var.getName().equals("labels")){
				String key = LongShortConverter.l2s(var.getName());

				Object val = null;
				var.setAccessible(true);
				try {
					val = var.get(dto);
				} catch (Exception e) {
					e.printStackTrace();
				}

				if(val != null){
					if(var.getType().equals(Integer.class)){
						jsonRes += "\"" + key  + "\": " + val + ", ";
					} else {
						jsonRes += "\"" + key  + "\": \"" + val + "\", ";
					}
				}

			} else if(var.getName().equals("labels")) {
				Object val = null;
				var.setAccessible(true);
				try {
					var.setAccessible(true);
					val = var.get(dto);
				} catch (Exception e) {
					e.printStackTrace();
				}

				List<String> list = (List<String>)val;
				if(list != null && list.size() >= 0){
					jsonRes += "\"" + LongShortConverter.l2s(var.getName()) + "\": [";
					for(int j = 0; j < list.size(); j++){
						jsonRes += "\"" + list.get(j) + "\", ";
					}
					jsonRes =  jsonRes.substring(0, jsonRes.length() - 2);
					jsonRes += "], ";
				}

			} else if (var.getName().equals("attribute")){

				Object val = null;
				var.setAccessible(true);
				try {
					var.setAccessible(true);
					val = var.get(dto);
				} catch (Exception e) {
					e.printStackTrace();
				}

				Map<String, Object> map = (Map<String, Object>)val;
				if(map == null){
					continue;
				}
				Set<String> keys = map.keySet();

				for(String key: keys){
					if(key.equals("currentNrOfInstances")
							|| key.equals("currentByteSize")
							|| key.equals("accessControlPolicyIDs")
							){
						continue;
					}

					if(!(map.get(key) instanceof ArrayList)){
						jsonRes += "\"" + LongShortConverter.l2s(key) + "\": \"" + map.get(key) + "\", ";
					} else {

						if(map.get(key) != null && ((ArrayList)map.get(key)).size() >= 0){
							jsonRes += "\"" + LongShortConverter.l2s(key) + "\": [";
							for(int j = 0; j < ((ArrayList)map.get(key)).size(); j++){
								jsonRes += "\"" + ((ArrayList)map.get(key)).get(j) + "\", ";
							}
							jsonRes =  jsonRes.substring(0, jsonRes.length() - 2);
							jsonRes += "], ";
						}
					}
				}
			}

		}

		jsonRes =  jsonRes.substring(0, jsonRes.length() - 2);
		jsonRes = "{\"" + resourceTypeName + "\":{" + jsonRes + "}}";

		LOGGER.debug(jsonRes);

		LOGGER.info("End resourceToJson");

		return jsonRes;
	}

	public static String notificationToJson(NotificationDTO notification){
		String jsonRes = "";
		String resourceTypeName = "m2m:sgn";

		Field[] varArray = notification.getClass().getFields();
		for(int i = 0; i < varArray.length; i++){
			Field var = varArray[i];

			String key = LongShortConverter.l2s(var.getName());

			Object val = null;
			var.setAccessible(true);
			try {
				val = var.get(notification);
			} catch (Exception e) {
				e.printStackTrace();
			}

			if(val != null){
				if(var.getType().equals(Integer.class)){
					jsonRes += "\"" + key  + "\" : " + val + ", ";
				} else if(var.getType().equals(String.class)) {
					jsonRes += "\"" + key  + "\" : \"" + val + "\", ";
				} else if(var.getType().equals(Boolean.class)) {
					if((Boolean)val){
						jsonRes += "\"" + key  + "\" : true, ";
					} else {
						jsonRes += "\"" + key  + "\" : false, ";
					}
				} else if(var.getType().equals(Map.class)) {
					jsonRes += "\"" + key  + "\" : {";

					Map<String, Object> map = (Map<String, Object>)val;
					Set<String> mapKeys = map.keySet();

					for(String mapKey: mapKeys){

						if(map.get(mapKey) instanceof String){
							jsonRes += "\"" + LongShortConverter.l2s(mapKey) + "\" : \"" + map.get(mapKey) + "\", ";
						} else 	if(map.get(mapKey) instanceof Integer){
							jsonRes += "\"" + LongShortConverter.l2s(mapKey) + "\" : " + map.get(mapKey) + ", ";
						} else if(map.get(mapKey) instanceof Map){

							if(map.get(mapKey) != null && ((ArrayList)map.get(mapKey)).size() >= 0){
								jsonRes += "\"" + LongShortConverter.l2s(mapKey) + "\": [";
								for(int j = 0; j < ((ArrayList)map.get(mapKey)).size(); j++){
									jsonRes += "\"" + ((ArrayList)map.get(mapKey)).get(j) + "\", ";
								}
								jsonRes =  jsonRes.substring(0, jsonRes.length() - 2);
								jsonRes += "], ";
							}
						}
					}
					jsonRes =  jsonRes.substring(0, jsonRes.length() - 2);
					jsonRes += "}, ";
				}
			}
		}

		jsonRes =  jsonRes.substring(0, jsonRes.length() - 2);
		jsonRes = "{\"" + resourceTypeName + "\":{" + jsonRes + "}}";

		return jsonRes;
	}

	private static class UnknownObject {
		@JsonIgnore
		private Map<String, Object> anyProperties = new HashMap<>();

		@JsonAnyGetter
		public Map<String, Object> getAnyProperties() {
			return this.anyProperties;
		}

		@JsonAnySetter
		public void setAnyProperties(String name, Object value) {
			this.anyProperties.put(name, value);
		}
	}
}
