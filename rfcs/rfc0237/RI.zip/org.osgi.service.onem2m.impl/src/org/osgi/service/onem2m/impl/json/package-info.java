/**
 * This package includes json serialize for oneM2M service layer API.
 */
package org.osgi.service.onem2m.impl.json;
