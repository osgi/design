package org.osgi.service.onem2m.dto;

import org.osgi.dto.DTO;

/**
 * DTO expressing LocalTokenIdAssignment.
 */
public class LocalTokenIdAssignmentDTO extends DTO{
	@javax.xml.bind.annotation.XmlElement( required  = true)
	public java.lang.String localTokenID;
	@javax.xml.bind.annotation.XmlElement( required  = true)
	public java.lang.String tokenID;
}
