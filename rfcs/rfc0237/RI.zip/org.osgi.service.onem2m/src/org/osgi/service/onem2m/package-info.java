/**
 * This package includes essential implementation for oneM2M service layer API.
 */
package org.osgi.service.onem2m;
