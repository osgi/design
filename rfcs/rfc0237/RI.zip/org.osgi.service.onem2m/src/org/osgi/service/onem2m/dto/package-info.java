/**
 * This package contains OSGi DTOs used in oneM2M Service Layer API.
 */
package org.osgi.service.onem2m.dto;
